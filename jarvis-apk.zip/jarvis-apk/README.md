# ◈ JARVIS Browser — Android APK
## Stark Industries · Full Android Browser

---

## BUILD THE APK — 3 WAYS

### WAY 1: Android Studio (easiest, recommended)
1. Install **Android Studio** → https://developer.android.com/studio
2. Open Android Studio → **Open** → select this folder (`jarvis-apk`)
3. Wait for Gradle sync (~2-3 min first time)
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK appears in `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer to phone → install (enable "Unknown sources" in Android settings)

### WAY 2: Command line (if you have Android SDK)
```bash
# Set your Android SDK path
export ANDROID_HOME=~/Android/Sdk    # Linux/Mac
# or: set ANDROID_HOME=C:\Users\YOU\AppData\Local\Android\Sdk  (Windows)

# Build debug APK
./gradlew assembleDebug              # Linux/Mac
gradlew.bat assembleDebug            # Windows

# APK location:
# app/build/outputs/apk/debug/app-debug.apk
```

### WAY 3: Online builder — no install needed
1. Zip this entire folder
2. Go to → https://appetize.io  or  https://buildozer.io
3. Upload the project → build → download APK

---

## INSTALL ON PHONE
1. Transfer `app-debug.apk` to your phone (USB, email, Drive, etc.)
2. On Android: **Settings → Security → Unknown Sources → ON**
   (or: Settings → Apps → Special app access → Install unknown apps)
3. Open the APK file → Install
4. Find **JARVIS Browser** in your app drawer

---

## FEATURES

### Browser Core
- Full Chromium WebView engine (same as Chrome)
- Multi-tab browsing (long-press tab to close)
- Back/Forward/Reload/Home navigation
- Address bar with smart URL/search detection
- Custom user agent (Chrome-compatible)

### JARVIS New Tab Page
- Animated arc reactor in SVG
- Live clock + date in Courier/monospace
- Hex grid + particle field canvas background
- Search bar (tap → search or navigate)
- Top sites grid from your bookmarks + history

### All Chrome-like Features
- **History** — full browsing history, searchable, clear all
- **Bookmarks** — save/manage/delete, shown in history
- **Downloads** — uses Android DownloadManager, shows in notification
- **Find in page** — search text on current page
- **Share page** — share URL to any Android app
- **Settings** — search engine, home page, history toggle
- **Error pages** — styled Stark error screen
- **File upload** — works in web forms
- **Location** — geo permission support
- **Media** — video/audio playback
- **New window** — opens in new tab

### Stark AR Interface
- Deep navy `#010a12` background throughout
- Cyan `#00d4ff` accent on all UI elements
- Monospace font everywhere
- Custom tab chips with glow border
- Animated arc reactor on new tab
- Hex grid + floating particles
- CRT scanline overlay

### Settings
- Search engine: Google / Bing / DuckDuckGo / Brave
- Custom home page URL
- Toggle history on/off
- Desktop site mode
- Clear all data (history + cache + cookies)

---

## CHROME SYNC NOTE
Android WebView runs on the device's Chrome engine automatically and
shares the same cookie store as Chrome on Android. Full bookmark sync
requires a signed Google account integration (Google Play Services API)
which needs a Play Console account. For local bookmarks, everything
saves on-device via SharedPreferences.

---

## REQUIREMENTS
- Android 8.0+ (API 26+)
- To build: Android Studio Hedgehog or newer
- JDK 17+ (bundled with Android Studio)

---

STARK INDUSTRIES © 3000 · MARK L · JARVIS v1.0
