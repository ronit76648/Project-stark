-keep class com.starkindustries.jarvis.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.google.gson.** { *; }
