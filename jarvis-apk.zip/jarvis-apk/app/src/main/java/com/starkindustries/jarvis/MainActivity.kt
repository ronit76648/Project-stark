package com.starkindustries.jarvis

import android.Manifest
import android.app.DownloadManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

// ── Data models ──────────────────────────────────────────────────────────────
data class Tab(
    val id: Int,
    var url: String = "jarvis://newtab",
    var title: String = "New Tab",
    var favicon: Bitmap? = null
)
data class HistoryItem(val url: String, val title: String, val time: Long)
data class Bookmark(val title: String, val url: String)
data class DownloadItem(val filename: String, val url: String, val size: Long, val time: Long)

// ── MainActivity ─────────────────────────────────────────────────────────────
class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var urlBar: EditText
    private lateinit var webView: WebView
    private lateinit var newTabView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var tabsContainer: LinearLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var btnBookmark: ImageButton

    // State
    private val tabs = mutableListOf<Tab>()
    private var activeTabId = 0
    private var tabCounter = 0
    private val history = mutableListOf<HistoryItem>()
    private val bookmarks = mutableListOf<Bookmark>()
    private val downloads = mutableListOf<DownloadItem>()
    private val gson = Gson()
    private val PREFS = "stark_prefs"
    private val SEARCH_ENGINES = mapOf(
        "Google"     to "https://www.google.com/search?q=",
        "Bing"       to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Brave"      to "https://search.brave.com/search?q="
    )
    private var currentEngine = "Google"
    private var homeUrl = "jarvis://newtab"
    private var saveHistory = true

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            Toast.makeText(ctx, "◈ Download complete", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full-screen immersive
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(android.view.WindowInsets.Type.statusBars())
        } else {
            @Suppress("DEPRECATION")
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        window.statusBarColor = Color.parseColor("#010a12")
        window.navigationBarColor = Color.parseColor("#0A0A0A")

        setContentView(R.layout.activity_main)
        bindViews()
        loadPrefs()
        setupWebView()
        setupNewTabView()
        setupUrlBar()
        setupButtons()
        setupBottomBar()

        registerReceiver(downloadReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            RECEIVER_NOT_EXPORTED)

        // Open initial tab
        val intentUrl = intent?.data?.toString()
        newTab(intentUrl ?: homeUrl)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(downloadReceiver)
        savePrefs()
    }

    override fun onBackPressed() {
        if (webView.visibility == View.VISIBLE && webView.canGoBack()) webView.goBack()
        else if (tabs.size > 1) closeTab(activeTabId)
        else super.onBackPressed()
    }

    // ── Bind views ────────────────────────────────────────────────────────
    private fun bindViews() {
        urlBar        = findViewById(R.id.urlBar)
        webView       = findViewById(R.id.webView)
        newTabView    = findViewById(R.id.newTabView)
        progressBar   = findViewById(R.id.progressBar)
        tabsContainer = findViewById(R.id.tabsContainer)
        btnBack       = findViewById(R.id.btnBack)
        btnForward    = findViewById(R.id.btnForward)
        btnReload     = findViewById(R.id.btnReload)
        btnBookmark   = findViewById(R.id.btnBookmark)
    }

    // ── WebView setup ─────────────────────────────────────────────────────
    @SuppressWarnings("SetJavascriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled        = true
        settings.domStorageEnabled        = true
        settings.databaseEnabled          = true
        settings.loadWithOverviewMode     = true
        settings.useWideViewPort          = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls      = true
        settings.displayZoomControls      = false
        settings.allowFileAccess          = true
        settings.allowContentAccess       = true
        settings.mixedContentMode         = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode                = WebSettings.LOAD_DEFAULT
        settings.mediaPlaybackRequiresUserGesture = false
        settings.userAgentString          = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 JARVISBrowser/1.0"
        webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("jarvis://")) { handleJarvisUrl(url); return true }
                if (!url.startsWith("http")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true } catch (e: Exception) {}
                }
                return false
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
                progressBar.progress = 10
                urlBar.setText(url)
                updateTabUrl(activeTabId, url)
                updateNavButtons()
            }
            override fun onPageFinished(view: WebView, url: String) {
                progressBar.visibility = View.GONE
                urlBar.setText(url)
                updateTabTitle(activeTabId, view.title ?: url)
                updateNavButtons()
                if (saveHistory && url.isNotBlank() && !url.startsWith("jarvis://"))
                    addHistory(url, view.title ?: url)
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showErrorPage(error.description.toString())
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String) {
                updateTabTitle(activeTabId, title)
            }
            override fun onReceivedIcon(view: WebView, icon: Bitmap) {
                updateTabFavicon(activeTabId, icon)
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, true, false)
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                newTab("about:blank")
                return false
            }
            override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: FileChooserParams): Boolean {
                val intent = fileChooserParams.createIntent()
                try { startActivityForResult(intent, 1001) } catch (e: Exception) { filePathCallback.onReceiveValue(null) }
                return true
            }
        }

        // Download listener
        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            startDownload(url, userAgent, contentDisposition, mimetype, contentLength)
        }
    }

    private fun setupNewTabView() {
        val settings = newTabView.settings
        settings.javaScriptEnabled  = true
        settings.domStorageEnabled  = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort    = true
        newTabView.setBackgroundColor(Color.parseColor("#010a12"))
        newTabView.addJavascriptInterface(JarvisJSBridge(), "JarvisBridge")
        newTabView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (!url.startsWith("file://") && !url.startsWith("jarvis://")) {
                    navigate(url); return true
                }
                return false
            }
        }
    }

    // ── JS Bridge (new tab → Kotlin) ──────────────────────────────────────
    inner class JarvisJSBridge {
        @JavascriptInterface fun navigate(url: String) = runOnUiThread { this@MainActivity.navigate(url) }
        @JavascriptInterface fun newTab() = runOnUiThread { this@MainActivity.newTab("jarvis://newtab") }
        @JavascriptInterface fun getBookmarks(): String = gson.toJson(bookmarks)
        @JavascriptInterface fun getHistory(): String = gson.toJson(history.take(20))
        @JavascriptInterface fun getEngine(): String = currentEngine
    }

    // ── URL bar ───────────────────────────────────────────────────────────
    private fun setupUrlBar() {
        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                navigate(urlBar.text.toString())
                hideKeyboard()
                true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) urlBar.selectAll()
        }
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ── Toolbar buttons ───────────────────────────────────────────────────
    private fun setupButtons() {
        btnBack.setOnClickListener    { if (webView.canGoBack()) webView.goBack() }
        btnForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        btnReload.setOnClickListener  {
            if (progressBar.visibility == View.VISIBLE) webView.stopLoading()
            else webView.reload()
        }
        btnBookmark.setOnClickListener { bookmarkCurrent() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu() }
    }

    private fun setupBottomBar() {
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener      { navigate(homeUrl) }
        findViewById<ImageButton>(R.id.btnHistory).setOnClickListener   { showHistory() }
        findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener    { newTab("jarvis://newtab") }
        findViewById<ImageButton>(R.id.btnBookmarks).setOnClickListener { showBookmarks() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener  { showSettings() }
    }

    // ── Navigation ────────────────────────────────────────────────────────
    private fun normalizeUrl(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return "jarvis://newtab"
        if (t == "jarvis://newtab") return t
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        if (!t.contains(" ") && (t.contains(".") || t.startsWith("localhost"))) return "https://$t"
        return SEARCH_ENGINES[currentEngine]!! + Uri.encode(t)
    }

    fun navigate(rawUrl: String) {
        val url = normalizeUrl(rawUrl)
        if (url == "jarvis://newtab") {
            showNewTab()
            updateTabUrl(activeTabId, url)
            urlBar.setText("")
            return
        }
        showWebView()
        webView.loadUrl(url)
        urlBar.setText(url)
        updateTabUrl(activeTabId, url)
    }

    private fun handleJarvisUrl(url: String) {
        when {
            url == "jarvis://newtab" -> showNewTab()
            url == "jarvis://history" -> showHistory()
            url == "jarvis://bookmarks" -> showBookmarks()
            url == "jarvis://settings" -> showSettings()
        }
    }

    // ── Tab management ────────────────────────────────────────────────────
    fun newTab(url: String = "jarvis://newtab") {
        val tab = Tab(++tabCounter, url)
        tabs.add(tab)
        activeTabId = tab.id
        renderTabs()
        navigate(url)
    }

    private fun switchTab(id: Int) {
        activeTabId = id
        renderTabs()
        val tab = tabs.find { it.id == id } ?: return
        navigate(tab.url)
    }

    private fun closeTab(id: Int) {
        if (tabs.size == 1) { newTab(); return }
        val idx = tabs.indexOfFirst { it.id == id }
        tabs.removeAt(idx)
        if (activeTabId == id) switchTab(tabs[maxOf(0, idx - 1)].id)
        else renderTabs()
    }

    private fun renderTabs() {
        tabsContainer.removeAllViews()
        tabs.forEach { tab ->
            val chip = TextView(this).apply {
                text = if (tab.title.length > 18) tab.title.take(16) + "…" else tab.title
                textSize = 9f
                typeface = android.graphics.Typeface.MONOSPACE
                setTextColor(if (tab.id == activeTabId) Color.parseColor("#00d4ff") else Color.parseColor("#4400d4ff"))
                setPadding(20, 0, 40, 0)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
                ).apply { marginEnd = 4 }
                minWidth = 120
                maxWidth = 200
                setBackgroundResource(R.drawable.tab_bg)
                isSelected = tab.id == activeTabId
                setOnClickListener { switchTab(tab.id) }
                setOnLongClickListener { closeTab(tab.id); true }
            }
            // close X overlay
            val wrap = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
                ).apply { marginEnd = 2 }
            }
            wrap.addView(chip)
            val closeBtn = TextView(this).apply {
                text = "✕"
                textSize = 9f
                setTextColor(Color.parseColor("#5500d4ff"))
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(28, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.END)
                setOnClickListener { closeTab(tab.id) }
            }
            wrap.addView(closeBtn)
            tabsContainer.addView(wrap)
        }
        // + new tab button
        val addBtn = TextView(this).apply {
            text = " ＋ "; textSize = 14f
            setTextColor(Color.parseColor("#4400d4ff"))
            setPadding(12,0,12,0); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT)
            setOnClickListener { newTab("jarvis://newtab") }
        }
        tabsContainer.addView(addBtn)
    }

    private fun updateTabUrl(id: Int, url: String) { tabs.find { it.id == id }?.url = url }
    private fun updateTabTitle(id: Int, title: String) { tabs.find { it.id == id }?.title = title; renderTabs() }
    private fun updateTabFavicon(id: Int, bmp: Bitmap) { tabs.find { it.id == id }?.favicon = bmp }
    private fun updateNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.35f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.35f
    }

    // ── New tab page ──────────────────────────────────────────────────────
    private fun showNewTab() {
        webView.visibility    = View.GONE
        newTabView.visibility = View.VISIBLE
        urlBar.setText("")
        updateNavButtons()
        loadNewTabPage()
    }

    private fun showWebView() {
        newTabView.visibility = View.GONE
        webView.visibility    = View.VISIBLE
    }

    private fun loadNewTabPage() {
        val html = buildNewTabHtml()
        newTabView.loadDataWithBaseURL("jarvis://newtab", html, "text/html", "UTF-8", null)
    }

    private fun buildNewTabHtml(): String {
        val bkJson = gson.toJson(bookmarks.take(8))
        val histJson = gson.toJson(history.take(8))
        return """<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
:root{--c:#00d4ff;--f:monospace}
body{background:#010a12;color:var(--c);font-family:var(--f);height:100vh;overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:16px}
canvas#bg{position:fixed;inset:0;z-index:0;pointer-events:none}
#scan{position:fixed;inset:0;z-index:1;pointer-events:none;background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,.07) 3px,rgba(0,0,0,.07) 4px)}
#inner{position:relative;z-index:5;display:flex;flex-direction:column;align-items:center;gap:14px;width:100%}
#clock{font-size:clamp(28px,8vw,52px);letter-spacing:4px;text-shadow:0 0 18px var(--c),0 0 36px rgba(0,212,255,.3)}
#date{font-size:9px;letter-spacing:2px;color:rgba(0,212,255,.4);text-align:center}
svg#arc{opacity:.8}
#search-wrap{position:relative;width:100%;max-width:480px}
#search{width:100%;padding:12px 14px 12px 38px;background:rgba(0,18,36,.75);border:1px solid rgba(0,212,255,.3);border-radius:4px;color:var(--c);font-family:var(--f);font-size:13px;outline:none;-webkit-appearance:none}
#search::placeholder{color:rgba(0,212,255,.28)}
#s-icon{position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:14px;color:rgba(0,212,255,.4)}
#sites{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;max-width:480px}
.site{display:flex;flex-direction:column;align-items:center;gap:4px;padding:10px 12px;background:rgba(0,18,36,.55);border:1px solid rgba(0,212,255,.15);border-radius:3px;font-size:8px;letter-spacing:.5px;color:rgba(0,212,255,.55);min-width:64px;text-align:center;cursor:pointer;-webkit-user-select:none}
.site img{width:20px;height:20px;border-radius:2px}
#logo{font-size:8px;letter-spacing:5px;color:rgba(0,212,255,.28)}
</style></head><body>
<canvas id="bg"></canvas><div id="scan"></div>
<div id="inner">
  <div id="logo">◈ STARK · JARVIS</div>
  <div id="clock">--:--:--</div>
  <div id="date">--</div>
  <svg id="arc" viewBox="0 0 160 160" width="120" height="120" xmlns="http://www.w3.org/2000/svg">
    <defs><radialGradient id="cg"><stop offset="0%" stop-color="#fff"/><stop offset="20%" stop-color="#a0eeff"/><stop offset="55%" stop-color="#00d4ff"/><stop offset="88%" stop-color="#004488"/><stop offset="100%" stop-color="#010a12"/></radialGradient><filter id="gf"><feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
    <circle cx="80" cy="80" r="74" fill="none" stroke="rgba(0,212,255,.1)" stroke-width="1"/>
    <circle cx="80" cy="80" r="66" fill="none" stroke="rgba(0,212,255,.18)" stroke-width="1"/>
    <circle id="sp1" cx="80" cy="80" r="60" fill="none" stroke="rgba(0,212,255,.6)" stroke-width="1.5" stroke-dasharray="50 327" stroke-linecap="round"/>
    <circle id="sp2" cx="80" cy="80" r="52" fill="none" stroke="rgba(0,150,255,.45)" stroke-width="1.5" stroke-dasharray="35 293" stroke-linecap="round"/>
    <circle cx="80" cy="80" r="40" fill="none" stroke="rgba(0,212,255,.35)" stroke-width="1.5"/>
    <circle id="core" cx="80" cy="80" r="22" fill="url(#cg)" filter="url(#gf)"/>
    <circle cx="80" cy="80" r="9" fill="rgba(210,245,255,.9)" filter="url(#gf)"/>
  </svg>
  <div id="search-wrap">
    <span id="s-icon">⌕</span>
    <input id="search" type="text" placeholder="Search the web or enter a URL..." enterkeyhint="go"/>
  </div>
  <div id="sites"></div>
</div>
<script>
const DAYS=['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
const MONTHS=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
function pad(n){return String(n).padStart(2,'0')}
function tick(){const n=new Date();document.getElementById('clock').textContent=pad(n.getHours())+':'+pad(n.getMinutes())+':'+pad(n.getSeconds());document.getElementById('date').textContent=DAYS[n.getDay()]+' · '+pad(n.getDate())+' '+MONTHS[n.getMonth()]+' '+n.getFullYear();}
setInterval(tick,1000);tick();

// Arc
let a=0;
(function animArc(){a++;const s1=document.getElementById('sp1'),s2=document.getElementById('sp2'),cr=document.getElementById('core');
if(s1)s1.setAttribute('stroke-dashoffset',-(a*2)%377);
if(s2)s2.setAttribute('stroke-dashoffset',(a*1.7)%328);
if(cr){const p=.5+.5*Math.sin(a*.04);cr.setAttribute('r',(20+p*3).toFixed(1));}
requestAnimationFrame(animArc);})();

// Search
document.getElementById('search').addEventListener('keydown',function(e){if(e.key==='Enter'){const v=this.value.trim();if(v)window.JarvisBridge&&JarvisBridge.navigate(v);}});

// Top sites from bookmarks + history
const bk=${bkJson}, hist=${histJson};
const seen=new Set(),items=[];
[...bk,...hist].forEach(s=>{if(s.url&&!seen.has(s.url)){seen.add(s.url);items.push(s);}});
const grid=document.getElementById('sites');
items.slice(0,8).forEach(s=>{
  const div=document.createElement('div');div.className='site';
  let fav='';try{const u=new URL(s.url);fav='<img src="https://www.google.com/s2/favicons?domain='+u.hostname+'&sz=32" onerror="this.style.display=\'none\'">';}catch(e){}
  div.innerHTML=fav+'<span>'+(s.title||s.url||'').slice(0,10)+'</span>';
  div.onclick=()=>window.JarvisBridge&&JarvisBridge.navigate(s.url);
  grid.appendChild(div);
});

// BG canvas
const cv=document.getElementById('bg'),ctx=cv.getContext('2d');
let W,H;
function resize(){W=cv.width=window.innerWidth;H=cv.height=window.innerHeight;}resize();window.addEventListener('resize',resize);
function hexPts(cx,cy,r){const p=[];for(let i=0;i<6;i++){const a=Math.PI/180*(60*i-30);p.push([cx+r*Math.cos(a),cy+r*Math.sin(a)]);}return p;}
const PARTS=Array.from({length:28},()=>({x:Math.random()*2000,y:Math.random()*2000,vx:(Math.random()-.5)*.18,vy:(Math.random()-.5)*.18,r:Math.random()*1.2+.3,a:Math.random()*.35+.07}));
function drawBg(){ctx.clearRect(0,0,W,H);ctx.fillStyle='#010a12';ctx.fillRect(0,0,W,H);
const r=26,sx=r*Math.sqrt(3),sy=r*1.5;ctx.strokeStyle='rgba(0,65,105,.2)';ctx.lineWidth=.5;
for(let row=-1;row<H/sy+2;row++)for(let col=-1;col<W/sx+2;col++){const cx=col*sx+(row%2?sx/2:0),cy=row*sy,pts=hexPts(cx,cy,r-1);ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.stroke();}
ctx.fillStyle='rgba(0,212,255,.4)';PARTS.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;ctx.globalAlpha=p.a;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();});ctx.globalAlpha=1;
requestAnimationFrame(drawBg);}drawBg();
</script></body></html>"""
    }

    // ── History ───────────────────────────────────────────────────────────
    private fun addHistory(url: String, title: String) {
        history.removeAll { it.url == url }
        history.add(0, HistoryItem(url, title, System.currentTimeMillis()))
        if (history.size > 500) history.removeAt(history.lastIndex)
        savePrefs()
    }

    private fun showHistory() {
        val items = history.take(50)
        if (items.isEmpty()) { toast("No history yet"); return }
        val names = items.map { "${it.title.take(40)}\n${it.url.take(50)}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("◈ BROWSING HISTORY")
            .setItems(names) { _, idx -> navigate(items[idx].url) }
            .setNegativeButton("Clear all") { _, _ -> history.clear(); savePrefs(); toast("History cleared") }
            .setPositiveButton("Close", null)
            .show()
            .window?.decorView?.setBackgroundColor(Color.parseColor("#010a12"))
    }

    // ── Bookmarks ─────────────────────────────────────────────────────────
    private fun bookmarkCurrent() {
        val tab = tabs.find { it.id == activeTabId } ?: return
        if (tab.url == "jarvis://newtab") return
        if (bookmarks.any { it.url == tab.url }) { toast("Already bookmarked"); return }
        bookmarks.add(0, Bookmark(tab.title.ifBlank { tab.url }, tab.url))
        savePrefs()
        toast("◈ Bookmarked: ${tab.title.take(30)}")
        btnBookmark.setColorFilter(Color.parseColor("#00d4ff"))
    }

    private fun showBookmarks() {
        if (bookmarks.isEmpty()) { toast("No bookmarks yet"); return }
        val names = bookmarks.map { it.title.take(45) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("◈ BOOKMARKS")
            .setItems(names) { _, idx -> navigate(bookmarks[idx].url) }
            .setNegativeButton("Close", null)
            .setNeutralButton("Manage") { _, _ -> showManageBookmarks() }
            .show()
    }

    private fun showManageBookmarks() {
        val names = bookmarks.map { "✕  ${it.title.take(38)}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("◈ MANAGE BOOKMARKS")
            .setItems(names) { _, idx ->
                AlertDialog.Builder(this)
                    .setMessage("Remove '${bookmarks[idx].title}'?")
                    .setPositiveButton("Remove") { _, _ -> bookmarks.removeAt(idx); savePrefs() }
                    .setNegativeButton("Cancel", null).show()
            }
            .setPositiveButton("Done", null).show()
    }

    // ── Downloads ─────────────────────────────────────────────────────────
    private fun startDownload(url: String, ua: String, cd: String, mime: String, size: Long) {
        val filename = URLUtil.guessFileName(url, cd, mime)
        val req = DownloadManager.Request(Uri.parse(url)).apply {
            addRequestHeader("User-Agent", ua)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
            setTitle(filename)
            setDescription("Downloading via JARVIS Browser")
            setMimeType(mime)
        }
        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        downloads.add(0, DownloadItem(filename, url, size, System.currentTimeMillis()))
        savePrefs()
        toast("⬇ Downloading: $filename")
    }

    private fun showErrorPage(error: String) {
        webView.loadData("""<html><body style="background:#010a12;color:#00d4ff;font-family:monospace;padding:40px;text-align:center">
            <h2 style="font-size:14px;letter-spacing:4px;margin-bottom:16px">◈ CONNECTION ERROR</h2>
            <p style="font-size:10px;color:rgba(0,212,255,.5);letter-spacing:1px">$error</p>
            <button onclick="history.back()" style="margin-top:24px;padding:10px 20px;background:rgba(0,212,255,.1);border:1px solid rgba(0,212,255,.3);color:#00d4ff;font-family:monospace;font-size:10px;letter-spacing:2px;cursor:pointer;border-radius:3px">◀ GO BACK</button>
            </body></html>""", "text/html", "UTF-8")
    }

    // ── Menu ─────────────────────────────────────────────────────────────
    private fun showMenu() {
        val options = arrayOf("⊕ New Tab", "⬇ Downloads", "⊟ Bookmarks", "◉ History",
            "⌕ Find in page", "◈ Share page", "⚙ Settings", "⌀ Clear data")
        AlertDialog.Builder(this)
            .setItems(options) { _, i -> when(i) {
                0 -> newTab("jarvis://newtab")
                1 -> showDownloadsList()
                2 -> showBookmarks()
                3 -> showHistory()
                4 -> showFindInPage()
                5 -> sharePage()
                6 -> showSettings()
                7 -> clearData()
            }}
            .show()
    }

    private fun showDownloadsList() {
        if (downloads.isEmpty()) { toast("No downloads yet"); return }
        val names = downloads.map { "⬇ ${it.filename.take(40)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("◈ DOWNLOADS").setItems(names) { _, _ -> }.setPositiveButton("Close", null).show()
    }

    private fun showFindInPage() {
        val input = EditText(this).apply { hint = "Find in page..."; setTextColor(Color.parseColor("#00d4ff")) }
        AlertDialog.Builder(this).setTitle("⌕ FIND IN PAGE").setView(input)
            .setPositiveButton("Find") { _, _ -> webView.findAllAsync(input.text.toString()) }
            .setNegativeButton("Close") { _, _ -> webView.clearMatches() }.show()
    }

    private fun sharePage() {
        val tab = tabs.find { it.id == activeTabId } ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, tab.url); putExtra(Intent.EXTRA_SUBJECT, tab.title)
        }, "Share via"))
    }

    private fun clearData() {
        AlertDialog.Builder(this).setTitle("Clear Data").setMessage("Clear history, cache and cookies?")
            .setPositiveButton("Clear all") { _, _ ->
                history.clear()
                webView.clearCache(true)
                webView.clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                savePrefs()
                toast("◈ Data cleared")
            }.setNegativeButton("Cancel", null).show()
    }

    // ── Settings ──────────────────────────────────────────────────────────
    private fun showSettings() {
        val engines = SEARCH_ENGINES.keys.toTypedArray()
        val currentIdx = engines.indexOf(currentEngine).coerceAtLeast(0)
        val options = arrayOf(
            "Search engine: $currentEngine",
            "Home page: $homeUrl",
            "Save history: ${if (saveHistory) "ON" else "OFF"}",
            "Request desktop site",
            "About JARVIS Browser"
        )
        AlertDialog.Builder(this).setTitle("⚙ SETTINGS").setItems(options) { _, i -> when(i) {
            0 -> AlertDialog.Builder(this).setTitle("Search Engine").setSingleChoiceItems(engines, currentIdx) { d, idx ->
                currentEngine = engines[idx]; savePrefs(); d.dismiss()
            }.setNegativeButton("Cancel",null).show()
            1 -> {
                val input = EditText(this).apply { setText(homeUrl); setTextColor(Color.parseColor("#00d4ff")) }
                AlertDialog.Builder(this).setTitle("Home Page").setView(input)
                    .setPositiveButton("Save") { _, _ -> homeUrl = input.text.toString(); savePrefs() }
                    .setNegativeButton("Cancel", null).show()
            }
            2 -> { saveHistory = !saveHistory; savePrefs(); toast("History: ${if(saveHistory) "ON" else "OFF"}") }
            3 -> { webView.settings.userAgentString = null; webView.reload() }
            4 -> AlertDialog.Builder(this).setTitle("JARVIS Browser v1.0")
                .setMessage("Stark Industries · Chromium Engine · Full Android Browser\n\nBuilt on Android WebView with JARVIS AR interface.")
                .setPositiveButton("Close", null).show()
        }}.setNegativeButton("Close", null).show()
    }

    // ── Persist ───────────────────────────────────────────────────────────
    private fun savePrefs() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE).edit()
        prefs.putString("history", gson.toJson(history.take(500)))
        prefs.putString("bookmarks", gson.toJson(bookmarks))
        prefs.putString("downloads", gson.toJson(downloads.take(100)))
        prefs.putString("engine", currentEngine)
        prefs.putString("home", homeUrl)
        prefs.putBoolean("saveHistory", saveHistory)
        prefs.apply()
    }

    private fun loadPrefs() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.getString("history", null)?.let {
            val type = object : TypeToken<List<HistoryItem>>() {}.type
            history.addAll(gson.fromJson(it, type) ?: emptyList())
        }
        prefs.getString("bookmarks", null)?.let {
            val type = object : TypeToken<List<Bookmark>>() {}.type
            bookmarks.addAll(gson.fromJson(it, type) ?: emptyList())
        }
        prefs.getString("downloads", null)?.let {
            val type = object : TypeToken<List<DownloadItem>>() {}.type
            downloads.addAll(gson.fromJson(it, type) ?: emptyList())
        }
        currentEngine = prefs.getString("engine", "Google") ?: "Google"
        homeUrl       = prefs.getString("home", "jarvis://newtab") ?: "jarvis://newtab"
        saveHistory   = prefs.getBoolean("saveHistory", true)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
